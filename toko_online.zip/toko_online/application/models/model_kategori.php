<?php 

class Model_kategori extends CI_Model{

	public function data_lemari_baju(){
		return $this->db->get_where("tb_barang",array('kategori' =>'lemari baju'));
	}

	public function data_rak_piring(){
		return $this->db->get_where("tb_barang",array('kategori' =>'rak piring'));
	}
}