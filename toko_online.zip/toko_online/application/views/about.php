<div class="container-fluid">
	
	<p class="text-center align-middle">Cv Gilang Sentosa</p>
	<p class="text-center align-middle">Sentosa ini perusahaan dagang bergerak di bidang produksi pembuatan perabotan berbahan baku kaca dan aluminium seperti lemari,rak piring,dan lain-lain.</p>
</div>
</div>